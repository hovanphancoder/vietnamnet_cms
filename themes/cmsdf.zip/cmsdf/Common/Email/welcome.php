<?php include '_header.php'; ?>
<div style="padding: 20px; font-size: 16px; line-height: 1.5;">
    <h3>Welcome to PhpFast, <?php echo $username; ?>!</h3>
    <p>We are excited to have you as a part of our community. You can now explore and enjoy all the features we offer on our platform.</p>
    <p>If you have any questions, feel free to contact us at <a href="mailto:contact@phpfast.net">contact@phpfast.net</a>.</p>
</div>
<?php include '_footer.php'; ?>