<!-- _header.php -->
<div style="background: linear-gradient(135deg, #007bff, #0056b3); padding: 30px 20px; text-align: center; color: #fff; border-radius: 8px 8px 0 0;">
    <div style="max-width: 600px; margin: 0 auto;">
        <h1 style="margin: 0; font-size: 28px; font-weight: bold; text-shadow: 0 2px 4px rgba(0,0,0,0.1);"><?= option('site_brand') ?></h1>
        <p style="margin: 8px 0 0 0; font-size: 16px; opacity: 0.9;">Authentication System</p>
    </div>
</div>
