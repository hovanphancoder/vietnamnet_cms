<?php
App\Libraries\Fastlang::load('Homepage');
//Render::asset('js', 'js/home-index.js', ['area' => 'frontend', 'location' => 'footer']);

//Get Object Data for this Pages
$locale = APP_LANG.'_'.strtoupper(lang_country(APP_LANG));


get_template('_metas/meta_all', ['locale' => $locale]);
//....
//End Get Object Data

?>


<!-- <?php// get_template('sections/taxonomy/taxonomy_main'); ?> -->

<?php get_footer(); ?>